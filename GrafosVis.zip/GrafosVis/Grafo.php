<?php
include_once("Conexion.php");
class Grafo
{
    private $vertices;
    private $aristas;
    private $dirigido;

    public function __construct($dirigido = true)
    {
        $this->vertices = null;
        $this->aristas = null;
        $this->dirigido = $dirigido;
    }

    public function agregarVertice($vertice)
    {
        if (!isset($this->vertices[$vertice->getId()])) {
            $this->aristas[$vertice->getId()] = null;
            $this->vertices[$vertice->getId()] = $vertice;
            return true;
        } else {
            return false;
        }
    }

    public function agregarArista($idVerticeOrigen, $idVerticeDestino, $peso = 1)
    {
        if (isset($this->vertices[$idVerticeOrigen]) && isset($this->vertices[$idVerticeDestino])) {
            $this->aristas[$idVerticeOrigen][$idVerticeDestino] = $peso;
            return true;
        } else {
            return false;
        }
    }

    /*
    * Elimina el vertice indicado y las aristas que lo relacionan con el resto del grafo.
    */
    public function eliminarVertice($idVerticeEliminar)
    {
        if (isset($this->vertices[$idVerticeEliminar]) && isset($this->aristas)) {
            foreach ($this->aristas as $vertice => $aristasDelVertice) {
                if (isset($aristasDelVertice)) {
                    foreach ($aristasDelVertice as $destino => $peso) {
                        if ($destino == $idVerticeEliminar) {
                            unset($this->aristas[$vertice][$destino]);
                        }
                    }
                }
            }
            unset($this->aristas[$idVerticeEliminar]);
            unset($this->vertices[$idVerticeEliminar]);
            return true;
        } else {
            return false;
        }
    }

    /*
    * Elimina la arista entre un nodo de origen y uno de destino.
    */
    public function eliminarArista($idVerticeOrigen, $idDVerticeDestino)
    {
        if (isset($this->aristas[$idVerticeOrigen][$idDVerticeDestino])) {
            unset($this->aristas[$idVerticeOrigen][$idDVerticeDestino]);
            return true;
        } else {
            return false;
        }
    }

    /*
    * Retorna los vertices adyacentes al vertice indicado. 
    */
    public function getVerticesAdyacentes($idVertice)
    {
        if (isset($this->vertices[$idVertice])) {
            $adyacentes = array();
            if ($this->gradoEntrada($idVertice) > 0) {
                foreach ($this->aristas as $vertice => $aristasDelVertice) {
                    if (isset($aristasDelVertice)) {
                        foreach ($aristasDelVertice as $destino => $peso) {
                             echo "Hola ".$destino;
                            if ($destino == $idVertice) {
                                $adyacentes[$vertice] = $destino;
                            }
                        }
                    }
                }
            }
            echo "Hola ".$idVertice;
            if ($this->gradoSalida($idVertice) > 0) {
                $adyacentes = array_merge($this->aristas[$idVertice], $adyacentes);
            }
            return $adyacentes;
        } else {
            return null;
        }
    }

    /*
    * Recibe el id del vertice y retorna grado de salida del mismo.
    */
    public function gradoSalida($idVertice)
    {
        if (isset($this->aristas[$idVertice])) {
            $verticesAdyacentes = $this->aristas[$idVertice];
            if (isset($verticesAdyacentes)) {
                return count($verticesAdyacentes);
            } else {
                return 0;
            }
        } else {
            return null;
        }
    }

    /*
    * Reotrna el grado de entrada del vertice indicado.
    */
    public function gradoEntrada($idVertice)
    {
        if (isset($this->vertices[$idVertice])) {
            $grado = 0;
            if (isset($this->aristas)) {
                foreach ($this->aristas as $vertice => $aristasDelVertice) {
                    if (isset($aristasDelVertice)) {
                        foreach ($aristasDelVertice as $destino => $peso) {
                            if ($destino == $idVertice) {
                                $grado++;
                            }
                        }
                    }
                }
            }
            return $grado;
        } else {
            return null;
        }
    }

    /*
    * Retorna el grado de un vertice.
    */
    public function grado($idVertice)
    {
        $gradoSalida = $this->gradoSalida($idVertice);
        $gradoEntrada = $this->gradoEntrada($idVertice);
        if (isset($gradoSalida) || isset($gradoEntrada)) {
            return $gradoSalida + $gradoEntrada;
        } else {
            return null;
        }
    }

    private function getVisitados()
    {
        $visitados = array();
        if (isset($this->vertices)) {
            foreach ($this->vertices as $id => $vertice) {
                $visitados[$id] = false;
            }
            return $visitados;
        } else {
            return null;
        }
    }

    /**
     * Retorna el vertice con la id especificada.
     */
    public function getVertice($id)
    {
        if (isset($this->vertices)) {
            return $this->vertices[$id];
        } else {
            return null;
        }
    }

    public function getVertices()
    {
        return $this->vertices;
    }

    public function setVertices($vertices)
    {
        $this->vertices = $vertices;
    }

    public function getAristas()
    {
        return $this->aristas;
    }

    public function setAristas($aristas)
    {
        $this->aristas = $aristas;
    }

    public function getDirigido()
    {
        return $this->dirigido;
    }

    public function setDirigido($dirigido)
    {
        $this->dirigido = $dirigido;
    }

    public function __toString()
    {
        if (isset($this->vertices)) {
            $grafoString = "";
            foreach ($this->vertices as $id => $vertice) {
                $grafoString .= "+ Vertice:<b>" . $id . "</b>|   Aristas:";
                if (isset($this->aristas[$id])) {
                    foreach ($this->aristas[$id] as $destino => $peso) {
                        $grafoString .= "<br>-   destino:" . $destino . ", peso:" . $peso;
                    }
                }
                $grafoString .= "<br><br>";
            }
            return $grafoString;
        } else {
            return "Grafo vacio";
        }
    }
}
?>